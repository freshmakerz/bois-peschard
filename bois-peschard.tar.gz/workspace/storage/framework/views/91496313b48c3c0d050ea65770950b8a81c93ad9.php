<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'La région', 'url' => '/la-region']
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.page-title', ['title' => 'La région'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns main-content">
                <?php echo $region->getStructuredText('region.content')->asHtml(); ?>

                <div class="carousel-slider">
                    <?php $__currentLoopData = $region->getGroup('region.slides')->getArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <img alt="" src="<?php echo e($slide->getImage('slide')->getUrl()); ?>">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>