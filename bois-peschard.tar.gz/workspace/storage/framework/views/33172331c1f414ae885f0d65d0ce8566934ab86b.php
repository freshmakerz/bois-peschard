<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'Gites', 'url' => '/gites']
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.page-title', ['title' => 'Gites de charme'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns main-content">
                <div class="row">
                    <?php $__currentLoopData = $gites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="medium-6 columns left text-center">
                        <div class="room-item">
                            <a href="<?php echo e(route('gite_show', ['slug' => $gite->getUid()])); ?>">
                                <img alt="" src="<?php echo e($gite->getImage('gites.thumbnail')->getUrl()); ?>">
                            </a>
                            <h4>
                                <a href="<?php echo e(route('gite_show', ['slug' => $gite->getUid()])); ?>"><?php echo e($gite->getText('gites.name')); ?></a>
                                <img src="/_assets/img/icons/<?php echo e($gite->getUid()); ?>.png" alt="" style="margin: -7px 0 0 10px;border:none;box-shadow:none;height:40px;">
                                <h6 style="text-transform:initial;font-style:italic;text-decoration: underline;"><?php echo e($gite->getText('gites.capacity')); ?> personnes</h6>
                            </h4>
                            <p><?php echo $gite->getStructuredText('gites.short-description')->asHtml(); ?></p>
                            <p>à partir de <b><?php echo e(number_format($gite->getNumber('gites.start-from')->getValue())); ?></b>€ / semaine</p>
                            <a href="/reservation?gite=<?php echo e($gite->getId()); ?>" class="button  tiny">
                                Je reserve
                            </a>
                            <a href="<?php echo e(route('gite_show', ['slug' => $gite->getUid()])); ?>" class="button secondary tiny">
                                Plus d'infos
                            </a>
                            <hr>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>