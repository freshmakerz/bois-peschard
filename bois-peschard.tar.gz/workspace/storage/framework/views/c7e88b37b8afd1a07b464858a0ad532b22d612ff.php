<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'Gites', 'url' => '/gites'],
        ['name' => $gite->getText('gites.name'), 'url' => '/gites/'.$gite->getUid()]
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.page-title', ['title' => $gite->getText('gites.name').'<img src="/_assets/img/icons/'.$gite->getUid().'.png" alt="" style="margin: -7px 0 0 15px;border:none;box-shadow:none;">'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns main-content inner"> 
                <div class="row">
                    <div class="medium-12 columns">
                        <div class="carousel-slider">
                            <?php $__currentLoopData = $gite->getGroup('gites.slides')->getArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <img alt="" src="<?php echo e($slide->getImage('slide')->getUrl()); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="medium-10 columns small-centered">
                        <div class="row">
                            <div class="medium-7 columns">
                                <h3>A propos</h3>
                                <?php echo $gite->getStructuredText('gites.long-description')->asHtml(); ?>

                                <p>A partir de <b><?php echo e($gite->getNumber('gites.start-from')->getValue()); ?></b>€/semaine (Basse saison)</p>
                                <p style="margin: 1.50rem 0 0 0;">
                                    <a href="/tarifs" class="button secondary tiny">Tarifs</a>
                                    <a href="/reservation" class="button tiny">Je réserve</a>
                                </p>
                            </div>
                            <div class="medium-5 columns">
                                <h3>Equipements & services</h3>
                                <?php echo $gite->getStructuredText('gites.features')->asHtml(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>