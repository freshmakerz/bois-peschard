<section class="breadcrumps-container">
    <div class="row">
        <div class="medium-12 columns">
            <ul class="breadcrumbs">
                <li><a href="/">Accueil</a></li>
                <?php if(isset($breadcrumbs)): ?>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->last): ?>
                        <li class="current"><a href="#"><?php echo e($breadcrumb['name']); ?></a></li>
                        <?php else: ?>
                        <li><a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</section>