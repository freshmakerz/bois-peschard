<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'Evenements', 'url' => '/evenements']
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.page-title', ['title' => 'Les évenements'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns">
                <div class="row">
                    <?php if($events): ?>
                        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="medium-12 columns">
                            <div class="event-item inner">
                                <div class="row">
                                    <div class="medium-12 columns">
                                        <h3><a href="<?php echo e($event['link']); ?>"><?php echo e($event['title']); ?></a></h3>
                                        <?php echo $event['description']; ?>                                     
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>