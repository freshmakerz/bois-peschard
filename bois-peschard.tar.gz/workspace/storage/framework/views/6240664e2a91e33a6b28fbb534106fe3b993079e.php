<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'Contact', 'url' => '/contact']
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns main-content">
                <h2 class="text-center">Contactez-nous</h2>
                <p class="lead text-center">
                    <a href="tel:+3361O030943">+(33) 6.1O.03.09.43</a>
                    <br><br>
                    Une question ? N'hésitez pas à nous envoyer un message.
                </p>
                <div class="row">
                    <div class="medium-8 columns medium-centered">
                        <?php if(Session::has('message_success')): ?>
                        <div class="row">
                            <div class="medium-12 columns">
                                <div data-alert class="alert-box success">
                                    Nous avons bien pris en compte votre demande.
                                    <a href="#" class="close">&times;</a>
                                </div>
                                <p>
                                    Nous vous recontacterons dans les plus brefs délais.
                                </p>
                            </div>
                        </div>
                        <?php else: ?>
                        <form action="/contact" method="POST">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <div class="row">
                                <div class="medium-6 columns">
                                    <div class="<?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                                        <input type="text" id="LastName" name="last_name" placeholder="Nom *" value="<?php echo e(old('last_name')); ?>" />
                                    </div>
                                    <div class="<?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                                        <input type="text" id="FirstName" name="first_name" placeholder="Prénom *" value="<?php echo e(old('first_name')); ?>" />
                                    </div>
                                    <input type="text" id="HomePhone" name="phone" placeholder="Téléphone" />
                                    <div class="<?php echo e($errors->has('email') ? 'has-error' : ''); ?>">    
                                        <input type="text" placeholder="Email *" name="email" id="EmailAddress" value="<?php echo e(old('email')); ?>" />
                                    </div>
                                    <select id="subject" name="subject">
                                        <option value="Réservation">Réservation</option>
                                        <option value="Partenariat"/>Partenariat</option>
                                        <option value="Autre"/>Autre</option>
                                    </select>
                                </div>
                                <div class="medium-6 columns">
                                    <div class="<?php echo e($errors->has('message') ? 'has-error' : ''); ?>">
                                        <textarea name="message" name="message" placeholder="Votre message *" id="" cols="30" rows="10" style="height:268px;" value="<?php echo e(old('message')); ?>"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="medium-12 columns">
                                    <input type="submit" value="Envoyer"/>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>