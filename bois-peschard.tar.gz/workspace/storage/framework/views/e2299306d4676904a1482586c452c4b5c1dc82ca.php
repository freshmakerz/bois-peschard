<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.breadcrumbs', ['breadcrumbs' => [
        ['name' => 'Les loisirs', 'url' => '/loisirs']
    ]], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.page-title', ['title' => 'Les loisirs'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="main">
        <div class="row">
            <div class="medium-12 columns main-content">
                <?php echo $loisirs->getStructuredText('loisirs.content')->asHtml(); ?>

                <div class="row">
                <?php $__currentLoopData = $loisirs->getGroup('loisirs.activities')->getArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="medium-12 columns">
                        <div class="row">
                            <?php if($loop->index % 2 == 0): ?>
                            <div class="medium-6 columns text-right">
                                <img src="<?php echo e($activity->getImage('thumbnail')->getUrl()); ?>" alt="" style="border: medium none;box-shadow: none;">
                            </div>
                            <div class="medium-6 columns top-heavy">
                                <?php echo $activity->getStructuredText('description')->asHtml(); ?>

                                <hr>
                            </div>
                            <?php else: ?>
                            <div class="medium-6 columns top-heavy">
                                <?php echo $activity->getStructuredText('description')->asHtml(); ?>

                                <hr>
                            </div>
                            <div class="medium-6 columns text-right">
                                <img src="<?php echo e($activity->getImage('thumbnail')->getUrl()); ?>" alt="" style="border: medium none;box-shadow: none;">
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partials.scroll-to-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>