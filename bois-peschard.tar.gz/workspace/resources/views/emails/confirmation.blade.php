<head></head>

<body>
  <div style="background-color:#fff;margin:0 auto 0 auto;padding:30px 0 30px 0;color:#4f565d;font-size:13px;line-height:20px;font-family:'Helvetica Neue',Arial,sans-serif;text-align:left;">
    <center>
      <table style="width:550px;text-align:center">
        <tbody>
          <tr>
            <td style="padding:0 0 20px 0;border-bottom:1px solid #e9edee;">
              <a href="https://www.xero.com/us/" style="display:block; margin:0 auto;" target="_blank">
                <img src="https://bois-peschard-freshmakerz.c9users.io/_assets/img/logo.jpg" height="100" alt="Bois Peschard logo" style="border: 0px;">
              </a>
            </td>
          </tr>
          <tr>
            <td colspan="2" style="padding:30px 0;">
              <p style="color:#1d2227;line-height:28px;font-size:22px;margin:12px 10px 20px 10px;font-weight:400;">Demande de réservation</p>
              <p style="margin:0 10px 10px 10px;padding:0;">Nous avons bien pris en compte votre demande de réservation et reviendrons très prochainement vers vous.</p>
              
            </td>
          </tr>
          <tr>
            <td colspan="2" style="padding:30px 0 0 0;border-top:1px solid #e9edee;color:#9b9fa5">
              Pour toute question vous pouvez nous contacter à <a style="color:#666d74;text-decoration:none;" href="contact@gites-boispeschard.com" target="_blank">contact@gites-boispeschard.com</a>
            </td>
          </tr>
        </tbody>
      </table>
    </center>
  </div>
</body>