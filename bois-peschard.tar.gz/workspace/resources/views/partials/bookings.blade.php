<section class="bookings">
    <div class="row">
        <div class="medium-6 columns">
            <div class="address">
                <div class="row">
                    <div class="medium-2 columns"><img alt="" src="/_assets/img/ui/compass.png" /></div>
                    <div class="medium-10 columns">
                        <h2>Gites Bois Peschard</h2>
                        <p>56910 Quelneuc</p>
                        <p>Morbihan - Bretagne</p>
                        <p><a href="mailto:contact@gites-boispeschard.com">contact@gites-boispeschard.com</a></p>
                        <p><a href="mailto:contact@gites-boispeschard.com" style="color: #7e7673;">+(33) 6.1O.03.09.43</a></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="medium-6 columns">
            <div class="logos">
                <div class="row">
                    <div class="medium-4 columns"><!--<em>find us on</em><img alt="" src="/_assets/img/logos/booking.png" />--></div>
                    <div class="medium-4 columns"><!--<em>find us on</em><img alt="" src="/_assets/img/logos/hotels.png" />--></div>
                    <div class="medium-4 columns"><a href="https://www.tripadvisor.fr/VacationRentalReview-g8737712-d12358150-Les_gites_du_Bois_Peschard-Quelneuc_Vannes_Morbihan_Brittany.html" target="_blank"><em>Trouvez-nous sur</em><img alt="" src="/_assets/img/logos/tripadvisor.png" /></a></div>
                </div>
            </div>
        </div>
    </div>
</section>