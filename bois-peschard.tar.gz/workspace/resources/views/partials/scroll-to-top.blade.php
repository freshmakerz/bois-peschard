<section class="top">
    <img alt="" src="/_assets/img/ui/anchor-top.png"><br>
    <em>Retour en haut</em>
</section>