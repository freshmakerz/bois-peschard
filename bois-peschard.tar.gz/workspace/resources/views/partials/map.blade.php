<section class="googlemap">
    <div id="map"></div>
</section>