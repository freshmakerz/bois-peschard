<section class="pagetitle">
    <div class="row">
        <div class="medium-12 columns">
            <h1 class="text-center">{!! $title !!}</h1>
        </div>
    </div>
</section>